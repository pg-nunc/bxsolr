package com.bgx.repo;

import javax.annotation.Resource;

import org.springframework.data.domain.Pageable;
import org.springframework.data.solr.core.SolrTemplate;
import org.springframework.data.solr.core.query.*;
import org.springframework.data.solr.core.query.result.FacetPage;

import com.bgx.entity.Product;

public class SolrProductRepositoryImpl implements SolrProductRepositoryCustom {

    @Resource
    private SolrTemplate solrTemplate;

    @Override
    public FacetPage<Product> findMaterialsBySearchInputWithRangeFacet(String name, String facetQuery, Pageable pageable) {
        FacetOptions facetOptions = new FacetOptions()
//                .addFacetByRange(
//                        new FacetOptions.FieldWithNumericRangeParameters("CLASSATTR_REACH", 0.0, 20.0, 1)
//                                .setHardEnd(true)
//                                .setInclude(FacetParams.FacetRangeInclude.ALL)
//                )
                .addFacetOnField("level3")
                .addFacetOnField("level4")
                .addFacetOnField("CLASSATTR_TOOL_CUTTING_EDGE_ANGLE")
                .addFacetOnField("CLASSATTR_REACH")
                .addFacetOnField("CLASSATTR_CUTTING_EDGES_PER_INSERT")
                .addFacetOnField("CLASSATTR_APP")
                .addFacetOnField("CLASSATTR_MACH_MATERIAL")
                .addFacetOnField("CLASSATTR_HLD_FRONT_END_TOOL_TYPE")
                .addFacetOnField("CLASSATTR_MIL_EFF_CUT_DIA_I")
                .addFacetOnField("CLASSATTR_MIL_MAX_CUT_DIA_I")
                .addFacetOnField(new FacetOptions.FieldWithFacetParameters("CLASSATTR_MIL_DOC_1_I").setSort(FacetOptions.FacetSort.INDEX))
                .addFacetOnField("CLASSATTR_ADAPTER_STYLE_VC")
                .addFacetOnField("CLASSATTR_MIL_NUM_EFF_FLUTES")
                .addFacetOnField("CLASSATTR_COOLANT_SUPPLY")
                .addFacetOnField("parentModuleCode");

        facetOptions.setFacetMinCount(1).setFacetLimit(10);
        String s = "module:false AND (Web_module_name:" + name +
                "^5 OR name:" + name +
                "^3 OR categoryNamesPath:" + name +
                ") AND (" + facetQuery + ")";


        Criteria criteria = new SimpleStringCriteria(s);
        SimpleFacetQuery simpleFacetQuery = new SimpleFacetQuery(criteria).setFacetOptions(facetOptions);
        FilterQuery filterQuery = new SimpleFilterQuery(new Criteria("level2").is("WIDIA").not().or("level2").is("Wear+Components").not());
        simpleFacetQuery.addFilterQuery(filterQuery);
        simpleFacetQuery.setPageRequest(pageable);
        return solrTemplate.queryForFacetPage(simpleFacetQuery, Product.class);
    }
}
