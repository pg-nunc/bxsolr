package com.bgx.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.bgx.entity.Product;

import java.util.List;
import java.util.Map;

/**
 * Created by Lenar on 8/3/2017.
 */
public interface ProductService {

  Product getProductByCode(String code);

  Page<Product> getMaterialsBySearchInput(String searchTerm, Map<String, List<String>> facetQuery, Pageable pageable);


  Page<Product> getModulesForSuggest(String searchTerm, Pageable pageable);
  Page<Product> getMaterialsForSuggest(String searchTerm, Pageable pageable);

  List<Product> getModulesBySearchInput(String name);

  Page<Product> getMaterialsForParentModuleCode(String moduleCode, Map<String, List<String>> facetQuery, Pageable pageable);


}
