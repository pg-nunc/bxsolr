package com.bgx.entity;

import java.util.List;

public class SuggestComponent {

    private List<Product> modules;
    private List<Product> materials;

    public SuggestComponent(List<Product> modules, List<Product> materials) {
        this.modules = modules;
        this.materials = materials;
    }

    public List<Product> getModules() {
        return modules;
    }

    public void setModules(List<Product> modules) {
        this.modules = modules;
    }

    public List<Product> getMaterials() {
        return materials;
    }

    public void setMaterials(List<Product> materials) {
        this.materials = materials;
    }
}
