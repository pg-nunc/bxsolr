package com.bgx.controller;

import java.io.IOException;
import java.util.*;

import javax.annotation.Resource;

import com.bgx.entity.SuggestComponent;
import com.bgx.util.SolrHelper;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.solr.core.query.SolrPageRequest;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bgx.entity.FacetCheckList;
import com.bgx.entity.Product;
import com.bgx.service.ProductService;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.Arrays;
import java.util.stream.Collectors;

/**
 * Created by Lenar on 8/02/2017.
 */
@RestController
@RequestMapping("/product")
public class MainController {

	@Resource
	private ProductService productService;

	/*
	 * For Pageable instance to evaluate automatically, add request parameters:
	 * page, size
	 */
	@RequestMapping(value = "/productSearch", method = RequestMethod.POST)
	public Page<Product> productSearch(@RequestParam(value = "search") String search,
			@RequestParam(value = "facetQuery", required = false) String facetQuery, Pageable pageable) {
		Map<String, List<String>> facetQueryMap = createFacetQueryMap(facetQuery);
		return productService.getMaterialsBySearchInput(search, facetQueryMap, pageable);
	}

	@RequestMapping(value="/productSearchTypAhead", method = RequestMethod.POST)
	public SuggestComponent productTypeAheadAutoFill(@RequestParam(value = "search") String search) {
		List<Product> modules = productService.getModulesForSuggest(search, new SolrPageRequest(0, 7)).getContent();
		List<Product> materials = productService.getMaterialsForSuggest(search, new SolrPageRequest(0, 7)).getContent();
		return new SuggestComponent(modules, materials);
	}

	@RequestMapping("/{code}")
	public Product code(@PathVariable String code) {
		return productService.getProductByCode(code);
	}

	@RequestMapping(value = "/moduleSearch", method = RequestMethod.POST)
	public List<Product> moduleSearch(@RequestParam(value = "search") String search) {
		return productService.getModulesBySearchInput(search);
	}


	@RequestMapping(value = "/module", method = RequestMethod.POST)
	public Page<Product> productFacetedByParentModule( @RequestParam(value = "moduleCode") String moduleCode,
													   @RequestParam(value = "facetQuery", required = false) String facetQuery,
													   @RequestParam(value = "search") String search,
													   Pageable pageable) {
		Map<String, List<String>> facetQueryMap = createFacetQueryMap(facetQuery);
		facetQueryMap.put("parentModuleCode", Collections.singletonList(moduleCode));
		return productService.getMaterialsBySearchInput(search, facetQueryMap, pageable);
	}



    private Map<String, List<String>> createFacetQueryMap(String facetQuery) {
        Map<String, List<String>> facetQueryMap = new HashMap<>();
        if (StringUtils.isNotBlank(facetQuery)) {
            FacetCheckList facetCheckList = new FacetCheckList();
            ObjectMapper mapper = new ObjectMapper();
            try {
                facetCheckList = mapper.readValue(facetQuery.getBytes(), facetCheckList.getClass());
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            if (facetCheckList != null && CollectionUtils.isNotEmpty(facetCheckList.getFacetChecklist())) {
                facetCheckList.getFacetChecklist().forEach(a -> {
                    List<String> selVal = new ArrayList<>();
                    a.getSelection().forEach(y -> selVal.add(y.getSelectVal()));
                    facetQueryMap.put(a.getField(), selVal);
                });
            }
        }
        return facetQueryMap;
    }

}