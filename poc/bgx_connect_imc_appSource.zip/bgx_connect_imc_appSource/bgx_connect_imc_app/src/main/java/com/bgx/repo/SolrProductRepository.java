package com.bgx.repo;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.solr.core.query.result.FacetPage;
import org.springframework.data.solr.repository.Facet;
import org.springframework.data.solr.repository.Query;
import org.springframework.data.solr.repository.SolrCrudRepository;

import com.bgx.entity.Product;

import java.util.List;
import java.util.Set;

/**
 * Created by Lenar on 8/02/2017.
 */

public interface SolrProductRepository extends SolrCrudRepository<Product, String>, SolrProductRepositoryCustom {

    @Query(filters = {"!level2:WIDIA", "!level2:Wear+Components"})
    Product findByModuleFalseAndCode(String code);

    @Query(value = "module:false AND (Web_module_name:?0^5 OR name:?0^3 OR categoryNamesPath:?0) AND (?1)", filters = {"!level2:WIDIA", "!level2:Wear+Components"})
    @Facet(fields = {"level3",
            "level4",
            "CLASSATTR_REACH",
            "CLASSATTR_TOOL_CUTTING_EDGE_ANGLE",
            "CLASSATTR_CUTTING_EDGES_PER_INSERT",
            "CLASSATTR_APP",
            "CLASSATTR_MACH_MATERIAL",
            "CLASSATTR_HLD_FRONT_END_TOOL_TYPE",
            "CLASSATTR_MIL_EFF_CUT_DIA_I",
            "CLASSATTR_MIL_MAX_CUT_DIA_I",
            "CLASSATTR_MIL_DOC_1_I",
            "CLASSATTR_ADAPTER_STYLE_VC",
            "CLASSATTR_MIL_NUM_EFF_FLUTES",
            "CLASSATTR_COOLANT_SUPPLY",
            "parentModuleCode"},
            limit = 10, minCount = 1)
    FacetPage<Product> findMaterialsBySearchInput(String name, String facetQuery, Pageable pageable);

    @Query(value = "module:false AND (Web_module_name:?0^5 OR name:?0^3 OR categoryNamesPath:?0)", filters = {"!level2:WIDIA", "!level2:Wear+Components"})
    @Facet(fields = {"parentModuleCode"}, limit = 100)
    FacetPage<Product> findMaterialsBySearchInputForModuleSearch(String searchInput, Pageable pageable);


    @Query(value = "module:(?0) AND (?1)", filters = {"!level2:WIDIA", "!level2:Wear+Components"})
    Page<Product> findItemsForSuggestions(boolean module, String suggestionsQuery, Pageable pageable);

    @Query(filters = {"!level2:WIDIA", "!level2:Wear+Components"})
    List<Product> findByModuleTrueAndCodeIn(Set<String> codes);

    @Query(value = "module:false AND (parentModuleCode:?0) AND (?1)", filters = {"!level2:WIDIA", "!level2:Wear+Components"})
    @Facet(fields = {"level3",
            "level4",
            "CLASSATTR_REACH",
            "CLASSATTR_TOOL_CUTTING_EDGE_ANGLE",
            "CLASSATTR_CUTTING_EDGES_PER_INSERT",
            "CLASSATTR_APP",
            "CLASSATTR_MACH_MATERIAL",
            "CLASSATTR_HLD_FRONT_END_TOOL_TYPE",
            "CLASSATTR_MIL_EFF_CUT_DIA_I",
            "CLASSATTR_MIL_MAX_CUT_DIA_I",
            "CLASSATTR_MIL_DOC_1_I",
            "CLASSATTR_ADAPTER_STYLE_VC",
            "CLASSATTR_MIL_NUM_EFF_FLUTES",
            "CLASSATTR_COOLANT_SUPPLY"},
            limit = 10, minCount = 1)
    FacetPage<Product> findByModuleFalseAndParentModuleCode(String parentModuleCode, String facetQuery, Pageable pageable);

}
