package com.bgx.entity;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import org.apache.solr.client.solrj.beans.Field;
import org.springframework.data.solr.core.mapping.Indexed;
import org.springframework.data.solr.core.mapping.SolrDocument;

/**
 * Created by Lenar on 8/02/2017.
 */
@SolrDocument(solrCoreName = "kmt_search_poc_core")
public class Product implements Serializable {

    private static final long serialVersionUID = -8243145429438016231L;

    @Indexed
    private String id;
    @Indexed
    private String code;
    @Indexed
    private String materials;
    @Indexed
    private String categoryPath;
    @Indexed
    private Boolean module;
    @Indexed
    private String name;
    @Indexed
    private String categoryNamesPath;
    @Indexed
    private String altCategoryPath;
    @Indexed
    private String altCategoryNamesPath;
    @Indexed
    private String parentModuleCode;
    @Indexed
    private String Page_Head_1;
    @Indexed
    private String Page_Head_2;
    @Indexed()
    private String Web_module_name;
    @Field("CLASSATTR_*")
    private Map<String, List<String>> classAttributes;

    private Long numberOfMaterials;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Product product = (Product) o;

        if (!id.equals(product.id)) return false;
        return code.equals(product.code);
    }

    @Override
    public int hashCode() {
        int result = id.hashCode();
        result = 31 * result + code.hashCode();
        return result;
    }


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMaterials() {
        return materials;
    }

    public void setMaterials(String materials) {
        this.materials = materials;
    }

    public String getCategoryPath() {
        return categoryPath;
    }

    public void setCategoryPath(String categoryPath) {
        this.categoryPath = categoryPath;
    }

    public Boolean getModule() {
        return module;
    }

    public void setModule(Boolean module) {
        this.module = module;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCategoryNamesPath() {
        return categoryNamesPath;
    }

    public void setCategoryNamesPath(String categoryNamesPath) {
        this.categoryNamesPath = categoryNamesPath;
    }

    public String getAltCategoryPath() {
        return altCategoryPath;
    }

    public void setAltCategoryPath(String altCategoryPath) {
        this.altCategoryPath = altCategoryPath;
    }

    public String getAltCategoryNamesPath() {
        return altCategoryNamesPath;
    }

    public void setAltCategoryNamesPath(String altCategoryNamesPath) {
        this.altCategoryNamesPath = altCategoryNamesPath;
    }

    public String getParentModuleCode() {
        return parentModuleCode;
    }

    public void setParentModuleCode(String parentModuleCode) {
        this.parentModuleCode = parentModuleCode;
    }

    public String getPage_Head_1() {
        return Page_Head_1;
    }

    public void setPage_Head_1(String page_Head_1) {
        Page_Head_1 = page_Head_1;
    }

    public String getPage_Head_2() {
        return Page_Head_2;
    }

    public void setPage_Head_2(String page_Head_2) {
        Page_Head_2 = page_Head_2;
    }

    public String getWeb_module_name() {
        return Web_module_name;
    }

    public void setWeb_module_name(String web_module_name) {
        Web_module_name = web_module_name;
    }

    public Map<String, List<String>> getClassAttributes() {
        return classAttributes;
    }

    public void setClassAttributes(Map<String, List<String>> classAttributes) {
        this.classAttributes = classAttributes;
    }

    public Long getNumberOfMaterials() {
        return numberOfMaterials;
    }

    public void setNumberOfMaterials(Long numberOfMaterials) {
        this.numberOfMaterials = numberOfMaterials;
    }
}
