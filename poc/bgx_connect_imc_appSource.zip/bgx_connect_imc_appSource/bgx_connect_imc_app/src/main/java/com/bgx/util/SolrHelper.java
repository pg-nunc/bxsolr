package com.bgx.util;

public class SolrHelper {

    public static String encodeSolrSearchString(String search)
    {
        String encoded = search.replace(" ", "+");
        return "\"" + encoded + "\"";
    }
}
