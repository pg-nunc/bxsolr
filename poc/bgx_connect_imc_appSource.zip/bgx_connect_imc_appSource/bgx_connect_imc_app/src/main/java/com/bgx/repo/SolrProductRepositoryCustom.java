package com.bgx.repo;

import com.bgx.entity.Product;
import org.springframework.data.domain.Pageable;
import org.springframework.data.solr.core.query.result.FacetPage;

public interface SolrProductRepositoryCustom {

    FacetPage<Product> findMaterialsBySearchInputWithRangeFacet(String name, String facetQuery, Pageable pageable);
}
