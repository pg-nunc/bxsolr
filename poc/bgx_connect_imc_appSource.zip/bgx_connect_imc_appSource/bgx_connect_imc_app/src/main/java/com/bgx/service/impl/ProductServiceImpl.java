package com.bgx.service.impl;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

import javax.annotation.Resource;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;

import com.bgx.entity.Product;
import com.bgx.repo.SolrProductRepository;
import com.bgx.service.ProductService;
import org.springframework.data.solr.core.query.Field;
import org.springframework.data.solr.core.query.SimpleField;
import org.springframework.data.solr.core.query.SolrPageRequest;
import org.springframework.data.solr.core.query.result.FacetFieldEntry;
import org.springframework.data.solr.core.query.result.FacetPage;
import org.springframework.data.solr.core.query.result.SimpleFacetFieldEntry;

import static com.bgx.util.SolrHelper.*;

/**
 * Created by Lenar on 8/3/2017.
 */
public class ProductServiceImpl implements ProductService {

    @Resource
    private SolrProductRepository solrProductRepository;


    @Override
    public Product getProductByCode(String code) {
        return solrProductRepository.findByModuleFalseAndCode(code);
    }

    @Override
    public Page<Product> getMaterialsBySearchInput(String searchTerm, Map<String, List<String>> facetQueryMap, Pageable pageable) {
        String facetQuery = buildSolrQueryFromMap(facetQueryMap);
        Product product = getProductByCode(searchTerm);
        if (product != null) {
            return new PageImpl<>(Collections.singletonList(product));
        }
        FacetPage<Product> materials = solrProductRepository.findMaterialsBySearchInputWithRangeFacet(encodeSolrSearchString(searchTerm), StringUtils.isEmpty(facetQuery) ? "*" : facetQuery, pageable);
        if (CollectionUtils.isEmpty(materials.getContent())) {
            materials = solrProductRepository.findMaterialsBySearchInputWithRangeFacet(searchTerm, StringUtils.isEmpty(facetQuery) ? "*" : facetQuery, pageable);
        }
        return materials;
    }


    @Override
    public Page<Product> getModulesForSuggest(String searchTerm, Pageable pageable) {
        Map<String, List<String>> variants = new HashMap<>();
        variants.put("autosuggest_en", new ArrayList<>());
        Arrays.stream(searchTerm.split(" ")).forEach(term -> variants.get("autosuggest_en").add(term + "*"));
        if (variants.get("autosuggest_en").size() > 1) {
            variants.get("autosuggest_en").add(searchTerm);
        }
        String suggestQuery = buildSolrQueryFromMap(variants);
        return solrProductRepository.findItemsForSuggestions(true, suggestQuery, pageable);
    }

    @Override
    public Page<Product> getMaterialsForSuggest(String searchTerm, Pageable pageable) {
        Map<String, List<String>> variants = new HashMap<>();
        variants.put("name", new ArrayList<>());
        Arrays.stream(searchTerm.split(" ")).forEach(term -> variants.get("name").add(term + "*"));
        if (variants.get("name").size() > 1) {
            variants.get("name").add(searchTerm);
        }
        String suggestQuery = buildSolrQueryFromMap(variants);
        return solrProductRepository.findItemsForSuggestions(false, suggestQuery, pageable);
    }

    @Override
    public List<Product> getModulesBySearchInput(String searchTerm) {
        Product product = getProductByCode(searchTerm);
        if (product != null) {
            return solrProductRepository.findByModuleTrueAndCodeIn(Collections.singleton(product.getParentModuleCode()));
        }

        FacetPage<Product> materials = solrProductRepository.findMaterialsBySearchInputForModuleSearch(encodeSolrSearchString(searchTerm), new SolrPageRequest(0, 500));
        if (CollectionUtils.isEmpty(materials.getContent())) {
            materials = solrProductRepository.findMaterialsBySearchInputForModuleSearch(searchTerm, new SolrPageRequest(0, 500));
        }
        Set<String> moduleCodes = new LinkedHashSet<>();
        Map<String, Long> moduleCode2Number = new HashMap<>();
        Page<FacetFieldEntry> parentModuleCodesFacet = materials.getFacetResultPage("parentModuleCode");
        parentModuleCodesFacet.forEach(e -> {
            moduleCodes.add(e.getValue());
            moduleCode2Number.put(e.getValue(), e.getValueCount());
        });
        List<Product> modules = solrProductRepository.findByModuleTrueAndCodeIn(moduleCodes);
        Map<String, Product> codeToModuleMap = modules.stream().collect(Collectors.toMap(Product::getCode, Function.identity()));
        List<Product> result = moduleCodes.stream().map(codeToModuleMap::get).collect(Collectors.toList());
        if (result.size() > 50) {
            result = result.subList(0, 50);
        }
        result.forEach(p -> p.setNumberOfMaterials(moduleCode2Number.get(p.getCode())));
        return result;
    }

    @Override
    public Page<Product> getMaterialsForParentModuleCode(String moduleCode, Map<String, List<String>> facetQueryMap, Pageable pageable) {
        String facetQuery = buildSolrQueryFromMap(facetQueryMap);
        return solrProductRepository.findByModuleFalseAndParentModuleCode(moduleCode, StringUtils.isEmpty(facetQuery) ? "*" : facetQuery, pageable);
    }


    private String buildSolrQueryFromMap(final Map<String, List<String>> facetQueryMap) {
        if (MapUtils.isEmpty(facetQueryMap)) return null;
        List<String> flattenedUpperLevel = new ArrayList<>();
        facetQueryMap.forEach((key, value) -> {
            List<String> flattened = new ArrayList<>();
            value.forEach(nextVal -> {
                if (nextVal.split("\\s+").length > 1) {
                    flattened.add(key + ":\"" + nextVal + "\"");
                } else {
                    flattened.add(key + ":" + nextVal);
                }
            });
            flattenedUpperLevel.add("(" + String.join(" OR ", flattened) + ")");
        });
        return String.join(" AND ", flattenedUpperLevel);
    }

    @Required
    public void setSolrProductRepository(SolrProductRepository solrProductRepository) {
        this.solrProductRepository = solrProductRepository;
    }

}
