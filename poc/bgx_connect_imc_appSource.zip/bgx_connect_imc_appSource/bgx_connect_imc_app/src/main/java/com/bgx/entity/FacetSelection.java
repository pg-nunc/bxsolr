package com.bgx.entity;

public class FacetSelection {
	private String selectVal;
	
	public FacetSelection() {
		super();
		// TODO Auto-generated constructor stub
	}

	public FacetSelection(String selectVal) {
		super();
		this.selectVal = selectVal;
	}

	public String getSelectVal() {
		return selectVal;
	}

	public void setSelectVal(String selectVal) {
		this.selectVal = selectVal;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((selectVal == null) ? 0 : selectVal.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FacetSelection other = (FacetSelection) obj;
		if (selectVal == null) {
			if (other.selectVal != null)
				return false;
		} else if (!selectVal.equals(other.selectVal))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "FacetSelection [selectVal=" + selectVal + "]";
	}

}
