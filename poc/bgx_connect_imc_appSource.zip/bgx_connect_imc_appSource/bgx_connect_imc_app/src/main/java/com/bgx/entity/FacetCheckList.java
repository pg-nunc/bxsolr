package com.bgx.entity;

import java.util.List;

public class FacetCheckList {
	private List<FacetCheck> facetChecklist;
	
	public FacetCheckList(List<FacetCheck> facetChecklist) {
		super();
		this.facetChecklist = facetChecklist;
	}

	public FacetCheckList() {
		super();
		// TODO Auto-generated constructor stub
	}


	public List<FacetCheck> getFacetChecklist() {
		return facetChecklist;
	}

	public void setFacetChecklist(List<FacetCheck> facetChecklist) {
		this.facetChecklist = facetChecklist;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((facetChecklist == null) ? 0 : facetChecklist.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FacetCheckList other = (FacetCheckList) obj;
		if (facetChecklist == null) {
			if (other.facetChecklist != null)
				return false;
		} else if (!facetChecklist.equals(other.facetChecklist))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "FacetCheckList [facetChecklist=" + facetChecklist + "]";
	}

}
