#!/bin/sh


cd ../bgx_connect_imc_app_resources/src
#Copy Dependencies--START
cp  app/config/bootstrap_magnify_bower_config.json bower_components/bootstrap-magnify
cp -R bower_components/bootstrap-sass-official/assets/stylesheets/bootstrap app/styles/sass
cp bower_components/bootstrap-sass-official/assets/stylesheets/_bootstrap.scss app/styles/sass
cp -R bower_components/bootstrap-sass-official/assets/stylesheets/bootstrap app/styles/sass-login
cp bower_components/bootstrap-sass-official/assets/stylesheets/_bootstrap.scss app/styles/sass-login
cd bower_components/bootstrap-magnify/
mv -f bootstrap_magnify_bower_config.json .bower.json
cd ../../
#Copy Dependencies -- END
#Copy Dependencies - END

# Run Grunt Serve dist comman
grunt --gruntfile Gruntfile.js serve:dist
cd ../
#Copy Dist to the Java Project
./BgxCopyDist.sh

cd src
grunt --gruntfile Gruntfile-login.js serve:dist
cd ../
./BgxCopyLoginDist.sh




#Run Java Build Command
cd ../bgx_connect_imc_app
mvn clean
mvn package

#Clean tomcat directory
cd /Applications/work/tomcat8/webapps
rm -rf bgx_connect_imc_app.war
rm -rf bgx_connect_imc_app

#copy the war file to the tomcat directory
cp /Users/dhananjay/Documents/workspaces/responsiveweb-kitchensink/bgx_connect_imc_app/target/bgx_connect_imc_app.war /Applications/work/tomcat8/webapps/bgx_connect_imc_app.war

cd ../bin
./startup.sh
